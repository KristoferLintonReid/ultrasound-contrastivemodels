
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from src.model import CLIPModel, RNAEncoder, ImageEncoder, ContrastiveLoss
from src.dataset import RNACustomDataset
from sklearn.model_selection import train_test_split

# Step 1: Prepare the data
# Assume the dataset has been loaded and preprocessed

# Split into train and test (you can change the data paths as needed)
rna_train, rna_test, img_train, img_test = train_test_split(rna_data_filtered, image_filenames, test_size=0.2)

train_dataset = RNACustomDataset(rna_train, img_train, transform=transform)
test_dataset = RNACustomDataset(rna_test, img_test, transform=transform)

train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=4, shuffle=False)

# Step 2: Initialize the Model, Optimizer, and Criterion
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

rna_encoder = RNAEncoder(input_dim=len(rna_cols.columns), embedding_dim=512)
image_encoder = ImageEncoder(embedding_dim=512)

model = CLIPModel(rna_encoder, image_encoder).to(device)
optimizer = optim.Adam(model.parameters(), lr=1e-4)
criterion = ContrastiveLoss(temperature=0.5)

# Step 3: Training Loop
epochs = 10
train(model, train_loader, test_loader, optimizer, criterion, device, epochs)
